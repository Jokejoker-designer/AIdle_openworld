# System Architecture

```text
Grok World Genesis Orchestrator
        │
        ├── World Concept Agent
        ├── Environment Layout Agent
        ├── Architecture Kit Agent
        ├── Nature/Biome Agent
        ├── Lighting Agent
        ├── Technical Optimization Agent
        └── QA/Review Agents
        │
        ▼
AIdle Blender Bridge API
        │
        ├── Environment Schema Validator
        ├── World Style Profile Registry
        ├── Module Registry
        ├── Material Registry
        ├── Scene Template Registry
        ├── Operation Allowlist
        ├── Job/Lease Manager
        └── Resource Policy
        │
        ▼
Blender Environment Worker
        │
        ├── Terrain Builder
        ├── Modular Architecture Assembler
        ├── Nature Scatter Builder
        ├── Landmark Builder
        ├── Lighting/Camera Preview Builder
        ├── LOD/HLOD Generator
        ├── Collision Hint Generator
        ├── Exporter
        └── Validator
        │
        ▼
Generated Quarantine
        │
        ├── GLB modules
        ├── Scene manifest
        ├── Preview renders
        ├── Metrics
        ├── Logs/hashes
        └── Provenance
        │
        ▼
Godot Intake Harness
        │
        ├── Import
        ├── Instantiate chunks
        ├── Bake navigation
        ├── Apply runtime collision
        ├── Test camera/occlusion
        ├── Test manifestation stages
        └── Save/reload regression
```

## Components

### Environment Gateway

Mở rộng FastAPI P0 với:

```text
GET  /v1/environment/templates
GET  /v1/environment/modules
GET  /v1/environment/world-profiles
POST /v1/environment/jobs
GET  /v1/environment/jobs/{job_id}
POST /v1/environment/jobs/{job_id}/cancel
POST /v1/environment/jobs/{job_id}/validate
POST /v1/environment/jobs/{job_id}/render
GET  /v1/environment/jobs/{job_id}/artifacts
```

Không tạo endpoint thực thi Python hoặc shell.

### Blender Worker profiles

```text
environment_module_worker
starter_realm_assembler
world_seed_diorama_worker
terrain_chunk_worker
preview_render_worker
```

P0E chỉ cần `starter_realm_probe_worker`.
