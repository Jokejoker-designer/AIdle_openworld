# Security, Quarantine and Validation

## Grok bị cấm

- arbitrary Python
- shell command
- add-on install
- download URL
- absolute path
- template overwrite
- approved catalog write
- runtime state mutation
- asset approval

## Blender worker

- chạy tài khoản OS riêng
- network disabled
- chỉ đọc template/library
- chỉ ghi current job/quarantine/evidence
- `--disable-autoexec`
- timeout
- max object count
- max mesh count
- max material count
- max output size

## Validation groups

### File safety

- không embedded script
- không external path lạ
- không missing texture
- file hash
- registry provenance

### Geometry

- dimensions
- transforms
- non-manifold
- hidden internal geometry
- triangle estimates
- LOD presence

### Scene layout

- bounds
- overlap
- path clearance
- build plot clearance
- camera occlusion
- landmark visibility
- elevation socket validity

### Style

- profile palette/material
- forbidden pattern
- silhouette readability
- native/adapted/anomaly classification
- surrealism budget

### Runtime readiness

- stable IDs
- module separation
- interaction markers
- navigation hints
- manifestation order
- deterministic seed
