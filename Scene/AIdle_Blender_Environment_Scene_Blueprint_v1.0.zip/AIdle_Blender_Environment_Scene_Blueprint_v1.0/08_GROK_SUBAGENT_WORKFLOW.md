# Grok Subagent Workflow for Exterior Scenes

## Agents

1. `World Style Guardian`
2. `Environment Layout Architect`
3. `Terrain Designer`
4. `Modular Architecture Designer`
5. `Nature and Biome Designer`
6. `Lighting and Camera Preview Designer`
7. `Optimization and Export Engineer`
8. `Blender Environment Production Agent`
9. `QA Evidence Agent`
10. `Red Scene Reviewer`
11. `Purple Scene Verifier`

## Order

```text
WORK_ORDER
→ STYLE_LOCK
→ LAYOUT_GRAPH
→ TERRAIN_RECIPE
→ MODULE_PLAN
→ NATURE_PLAN
→ LIGHTING_PREVIEW_PLAN
→ ENVIRONMENT_BUILD_SPEC
→ BLENDER_JOB
→ QUARANTINE
→ GODOT_INTAKE
→ RED
→ REWORK
→ PURPLE
→ CODEX/HUMAN
```

## Parent authority

Parent Orchestrator:

- không patch product file
- giữ file lease
- tối đa 5 child
- không cho child spawn grandchild
- không tự ACCEPT

## Blender Production Agent

Chỉ được gọi:

- inspect environment template
- inspect module registry
- create environment job
- get job status
- render preview
- validate environment package

Không được gọi shell/Python.
