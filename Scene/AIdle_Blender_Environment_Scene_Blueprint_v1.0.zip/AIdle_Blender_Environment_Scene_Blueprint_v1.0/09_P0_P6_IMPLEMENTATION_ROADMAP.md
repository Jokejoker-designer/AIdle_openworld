# P0E–P6E Roadmap

## P0E — Environment Bridge Skeleton

Mục tiêu:

- thêm environment endpoints vào P0 Bridge
- strict environment schema
- environment template registry
- operation allowlist
- mock job
- real Blender exterior probe
- quarantine/log/hash

Probe scene:

- flat terrain chunk
- simple path
- one cube house
- one tree proxy
- one pond proxy
- one build plot marker
- isometric camera
- GLB + preview + manifest

## P1E — Cozy Starter Realm Modular Kit

- small modular house
- path stones
- pond
- landmark tree
- farm plots
- Light Brush station
- build plot
- greenhouse hologram placeholder
- Cozy material family
- Godot intake harness

## P2E — Tiny Diorama

- cutaway block
- grid/elevation sockets
- movable grouped props
- limited camera preview
- recipe cluster export

## P3E — Solarpunk

- eco building add-ons
- vegetation layers
- water/energy modules
- degraded/restored visual states

## P4E — Arcane + Spirit

- physical/arcane layer metadata
- mechanical sockets
- temple/forest restoration state kits
- cloud/waterfall preview modules

## P5E — Surrealism

- anomaly region metadata
- controlled floating island/portal
- surrealism budget validation
- navigation-safe anomaly layout

## P6E — Oceanpunk

- depth-tier chunks
- bubble base modules
- coral/kelp kits
- occlusion and lighting hints
- underwater navigation prototype

Integration vẫn đi đúng thứ tự tracker; chuẩn bị library không đồng nghĩa world
runtime đã ACCEPTED.
