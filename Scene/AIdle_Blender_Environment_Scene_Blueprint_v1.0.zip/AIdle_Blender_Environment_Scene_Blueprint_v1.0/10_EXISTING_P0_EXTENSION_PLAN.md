# Existing P0 Bridge Extension Plan

Mở rộng repo `AIdle_Blender_Bridge_P0` theo hướng không phá Character API.

```text
app/
├── api/
│   ├── character_jobs.py
│   └── environment_jobs.py
├── schemas/
│   ├── character_request.py
│   └── environment_request.py
├── services/
│   ├── blender_runner.py
│   ├── character_job_service.py
│   └── environment_job_service.py
blender_scripts/
├── character_worker_entry.py
└── environment_worker_entry.py
templates/
├── characters/
└── environments/
libraries/
├── characters/
└── environments/
```

## Không dùng chung worker entry

Character và environment chia entrypoint để giảm blast radius.

## Dùng chung

- settings
- path policy
- idempotency
- job receipt
- log capture
- timeout
- quarantine
- hash manifest
- health endpoint

## P0E API additions

```text
GET /v1/environment/templates
GET /v1/environment/modules
POST /v1/environment/jobs
GET /v1/environment/jobs/{job_id}
POST /v1/environment/jobs/{job_id}/cancel
```

## P0E tests

1. reject unknown world profile
2. reject unknown module
3. reject arbitrary operation
4. reject absolute path
5. duplicate request returns same logical job or conflict according policy
6. deterministic mock manifest
7. cancel queued job
8. real probe exports GLB and preview
9. artifact paths remain quarantine-relative
10. character API regression remains green
