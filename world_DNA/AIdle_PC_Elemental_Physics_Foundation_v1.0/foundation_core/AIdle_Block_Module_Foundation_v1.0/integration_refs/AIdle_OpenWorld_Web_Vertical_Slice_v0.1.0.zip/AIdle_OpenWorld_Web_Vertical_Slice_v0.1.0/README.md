# AIdle OpenWorld Web Vertical Slice v0.1.0

Một vertical slice chạy thật cho **Cozy Cyber-Pixel / Dreamy Low-Poly 2.5D**.
Đây là implementation continuation của AIdle, không phải game mới.

## Có thể chơi

- Di chuyển bằng WASD/phím mũi tên hoặc joystick cảm ứng.
- Tương tác với luống cây, Nori-7, Light Brush và khu đất xây dựng.
- Mở AI Architect, nhập prompt tiếng Việt hoặc tiếng Anh.
- World Architect fallback tạo Structured World Proposal.
- Xem hologram, chỉnh proposal, chấp nhận hoặc từ chối.
- Manifestation theo stage: WIREFRAME → HOLOGRAM → MATERIALIZING → COMPLETE.
- Commit có revision check và idempotency.
- Save/load bằng localStorage, tự phục hồi sau reload.
- Undo bằng compensating mutation.
- Quest đầu tiên: xây nhà kính và đánh thức Nori-7.
- Farming loop: trồng → tưới → thu hoạch.
- PWA, responsive landscape và mobile controls.

## Chạy

```bash
npm start
```

Mở `http://127.0.0.1:4173`.

## Test

```bash
npm test
npm run check
```

## Giới hạn trung thực

- Môi trường xây dựng không có Godot hoặc Blender executable.
- Không có API key AI, nên game sử dụng `DeterministicWorldArchitect` làm fallback
  có contract tương thích AI Gateway.
- Blender Bridge và Godot intake hiện là adapter/boundary, chưa được thực thi ở
  môi trường này.
- Artifact này không tự thay đổi trạng thái canonical trong Scene Tracker.
