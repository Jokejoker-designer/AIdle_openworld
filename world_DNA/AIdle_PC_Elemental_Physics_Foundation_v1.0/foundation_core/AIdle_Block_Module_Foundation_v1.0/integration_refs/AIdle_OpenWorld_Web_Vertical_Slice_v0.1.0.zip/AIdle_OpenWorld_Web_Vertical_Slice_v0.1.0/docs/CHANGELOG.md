# Changelog

## 0.1.0 — 2026-07-21

- Reconstructed AIdle baseline from supplied blueprint, tracker and worklog.
- Implemented modular web/PWA Cozy vertical slice.
- Added touch controls, responsive HUD and prompt bottom sheets.
- Added deterministic World Architect fallback and AI Gateway route.
- Added Structured World Proposal, validation, preview and manifestation.
- Added idempotent World Commit, revision checks, save/load and undo.
- Added Nori-7 quest, Bụi Mơ/Bác Bắp proxies and farming loop.
- Added Blender Bridge boundary adapter.
- Added Node tests and evidence tooling.
