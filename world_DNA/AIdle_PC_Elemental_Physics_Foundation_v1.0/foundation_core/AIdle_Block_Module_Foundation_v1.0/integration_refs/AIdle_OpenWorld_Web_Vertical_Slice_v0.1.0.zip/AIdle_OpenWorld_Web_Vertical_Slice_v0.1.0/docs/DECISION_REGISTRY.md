# Decision Registry

| ID | Quyết định | Trạng thái | Ảnh hưởng implementation |
|---|---|---|---|
| ADR-001 | Private Reality 2.5D là MVP | LOCKED | Không voxel/open-continuum trong vertical slice |
| ADR-002 | Cozy Cyber-Pixel là world đầu tiên | LOCKED | Tất cả asset/proposal hiện tại dùng Cozy profile |
| ADR-003 | AI chỉ đề xuất, World Commit mới mutation | LOCKED | Planner tách khỏi commit service |
| ADR-004 | Structured World Prompt là contract duy nhất | LOCKED | Proposal được version hóa và validate |
| ADR-005 | Preview không có ownership/collision | LOCKED | Preview chỉ nằm ở `world.preview` |
| ADR-006 | request_id idempotency + revision check | LOCKED | Duplicate không sinh entity; stale revision bị reject |
| ADR-007 | Undo là compensating mutation | LOCKED | Lịch sử không bị xóa |
| ADR-008 | Godot là runtime mục tiêu; web-first phải tương thích | ACTIVE | Web vertical slice dùng adapter boundary, không tuyên bố thay Godot |
| ADR-009 | Blender là asset/scene worker, không phải world runtime | LOCKED | Blender adapter trả UNAVAILABLE khi chưa nối worker |
| ADR-010 | AI API ở backend; client không giữ key | LOCKED | Browser chỉ gọi `/api/ai/plan` |
| ADR-011 | Live model chưa có key trong môi trường | ACTIVE | Dùng deterministic fallback, không giả vờ là LLM |
| ADR-012 | Mobile là UX riêng, không chỉ thu nhỏ desktop | ACTIVE | Joystick, camera buttons, bottom sheets, safe areas |
