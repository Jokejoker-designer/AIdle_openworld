# Evidence Plan

Generated evidence directory:

- `test_output.txt`
- `check_output.txt`
- `server_health.json`
- `reference_desktop_initial.png`
- `reference_desktop_proposal.png`
- `reference_desktop_complete.png`
- `reference_mobile_initial.png`
- `BROWSER_EXECUTION_BLOCKER.md`
- `file_hashes.json`

A screenshot is evidence only, not workflow state. Acceptance remains external.

The reference renders are composition evidence only. Chromium acceptance is blocked by the environment policy and remains an external gate.
