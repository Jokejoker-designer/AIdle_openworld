# Execution Plan

## Phase VS-01 — Cozy web/PWA vertical slice

**Output:** artifact hiện tại.

Quality gates:

- prompt → proposal → validation → preview → confirm → manifestation → commit;
- invalid prompt rejected;
- cancel before commit;
- save/reload same IDs;
- duplicate request idempotent;
- revision conflict rejected;
- undo removes entities by compensating mutation;
- desktop and touch controls;
- one quest and farming loop.

## Phase VS-02 — Live AI Gateway

- provider-neutral server adapter;
- Structured Output response validation;
- quota/rate limit/audit;
- no client API key;
- deterministic fallback preserved.

## Phase VS-03 — Blender Environment P0E

- connect existing Blender Bridge P0;
- create real Cozy probe GLB and scene manifest;
- quarantine and validation;
- browser loads approved GLB through catalog.

## Phase VS-04 — Godot parity project

- import same world contracts and receipts;
- fixed-angle 3D runtime;
- web export and mobile input parity;
- replace procedural proxies with approved assets.

## Phase VS-05 — Authority backend

- server-side canonical state;
- authentication, ownership, revision conflicts;
- event/outbox and two-client test.

No phase may claim ACCEPTED without independent machine evidence and required HITL.
