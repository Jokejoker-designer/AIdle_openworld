# Implementation Gap Analysis

| Hệ thống | Đã thiết kế | Có source | Đã chạy | Khoảng trống |
|---|---:|---:|---:|---|
| Structured Prompt | Có | Có | Có | Chưa nối canonical schema repo gốc |
| Planner | Có | Có fallback | Có | Chưa nối live Grok/xAI/OpenAI provider |
| Validation | Có | Có | Có test | Spatial validation mới ở mức rectangle |
| Preview/Manifestation | Có | Có | Có | Chưa có mesh/GLB thật |
| World Commit | Có | Có | Có test | Hiện local-first, chưa authoritative server DB |
| Save/load/undo | Có | Có | Có test | localStorage, chưa PostgreSQL/Nakama |
| Cozy world | Có | Có procedural render | Có | Chưa có production low-poly assets |
| Farming | Có định hướng | Có | Có | Chưa có thời gian/sinh thái sâu |
| NPC | Foundry có | Có 3 runtime proxies | Có | Chưa có rig/animation/AI dialogue |
| Mobile controls | Có | Có | Có | Cần device matrix/HITL |
| PWA | Có | Có | Có shell | Cần production HTTPS/install test |
| Blender Bridge | Có blueprint/P0 | Có adapter | Chưa | Không có Blender executable |
| Godot runtime | Có baseline | Không có repo | Chưa | Cần repo/toolchain thật |
| Multiplayer | Roadmap H2/G6 | Không | Chưa | Bị block sau vertical slice |
