# Project Reconstruction Report — AIdle OpenWorld

## Product vision

AIdle là cozy creative 2.5D Private Reality nơi người chơi diễn đạt ý định bằng
ngôn ngữ, Companion biến ý định thành Structured World Proposal, runtime kiểm tra,
hiển thị bằng ánh sáng và chỉ commit sau khi người chơi xác nhận.

## Baseline đã khóa

- Cozy Cyber-Pixel / Dreamy Low-Poly, camera cố định ba phần tư/isometric.
- Structured World Prompt là proposal language duy nhất.
- AI proposes; authoritative World Commit mutates.
- Preview không tạo ownership/collision.
- request_id idempotency; expected_world_revision optimistic concurrency.
- Manifestation: WIREFRAME → HOLOGRAM → MATERIALIZING → COMMITTING → COMPLETE.
- MVP text-only; voice chỉ là placeholder/browser capability.
- Blender sinh/condition asset và scene modular bất đồng bộ, không phải runtime.
- World 1 Cozy phải hoàn tất trước World 2–7.

## Inventory trong môi trường

### Có blueprint/tài liệu

- AIdle Openworld Blueprint v1.1.
- World Genesis Blueprint và 7 world specifications.
- Character Foundry 28 nhân vật.
- Grok Character và World Genesis subagents.
- Blender Bridge P0 package.
- Blender Environment Scene Blueprint.
- Scene registry, tracker và append-only worklog.

### Không có trong môi trường

- Repo Godot hiện hành.
- Godot executable/export templates.
- Blender executable.
- Live AI API key/provider connection.
- Approved production GLB character/environment kit.

## Artifact triển khai hiện tại

Vertical slice web/PWA nhiều module được tạo để chứng minh core loop chạy thật:
movement, touch controls, farming, NPC, prompt planner fallback, validation,
hologram, confirmation, commit, persistence và undo.

Artifact này không thay thế Godot baseline dài hạn và không tự ACCEPT tracker.
