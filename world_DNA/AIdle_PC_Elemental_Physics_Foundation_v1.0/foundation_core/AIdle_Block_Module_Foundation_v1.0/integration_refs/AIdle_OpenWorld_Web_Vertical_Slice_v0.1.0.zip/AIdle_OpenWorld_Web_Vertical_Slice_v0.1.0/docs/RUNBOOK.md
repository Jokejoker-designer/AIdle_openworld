# Runbook

## Requirements

- Node.js 20+

## Start

```bash
npm start
```

Open `http://127.0.0.1:4173`.

## Controls

- WASD / arrows: movement
- Shift: faster movement
- E: interact
- `/`: open AI Architect
- C: Companion message
- Ctrl/Cmd+Z: undo
- Mobile: joystick, E, zoom ±

## Suggested acceptance run

1. Enter `Tạo một nhà kính hình giọt nước với đèn nhỏ phát sáng.`
2. Confirm hologram is visible and committed object is not yet present.
3. Edit palette or scale.
4. Confirm construction.
5. Reload page and verify greenhouse remains.
6. Walk to Nori-7 and press E.
7. Interact with a farm plot four times.
8. Press Undo and verify greenhouse is removed while revision increases.
