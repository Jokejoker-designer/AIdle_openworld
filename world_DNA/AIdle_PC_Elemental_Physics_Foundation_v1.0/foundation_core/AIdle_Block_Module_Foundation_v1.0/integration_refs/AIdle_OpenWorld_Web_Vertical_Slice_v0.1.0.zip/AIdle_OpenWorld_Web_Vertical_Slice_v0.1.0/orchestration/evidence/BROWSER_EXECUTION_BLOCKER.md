# Browser Execution Blocker

Attempted headed automation with installed Chromium 144 and Python Playwright.
The environment policy rejected navigation to both:

- `http://127.0.0.1:4173`
- `file:///mnt/data/.../public/index_test.html`

Error:

```text
Page.goto: net::ERR_BLOCKED_BY_ADMINISTRATOR
```

Therefore the package does not claim headed-browser verification. Reference PNGs
were rendered from the same Cozy world specification to review composition only;
they are not substitutes for a browser acceptance gate.
