import { access, readFile } from 'node:fs/promises';
const required=['public/index.html','public/manifest.webmanifest','public/sw.js','src/main.js','server/server.js','contracts/world_prompt.vertical_slice.schema.json','docs/PROJECT_RECONSTRUCTION_REPORT.md'];
let failed=false;for(const file of required){try{await access(file);console.log('PASS',file)}catch{console.error('FAIL',file);failed=true}}
const schema=JSON.parse(await readFile('contracts/world_prompt.vertical_slice.schema.json','utf8'));if(schema.additionalProperties!==false){console.error('FAIL strict schema');failed=true}else console.log('PASS strict schema');process.exitCode=failed?1:0;
