$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot\..
node server/server.js
