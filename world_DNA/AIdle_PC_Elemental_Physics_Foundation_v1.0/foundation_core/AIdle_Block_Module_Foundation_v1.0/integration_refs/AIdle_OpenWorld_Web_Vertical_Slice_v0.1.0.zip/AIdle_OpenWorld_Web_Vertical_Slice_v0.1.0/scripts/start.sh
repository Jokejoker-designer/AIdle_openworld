#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node server/server.js
