import { DeterministicWorldArchitect } from '../src/ai/worldPlanner.js';
import { createDefaultWorld } from '../src/world/defaultWorld.js';
const planner=new DeterministicWorldArchitect();
export async function handleAIPlan(body){
  const world=createDefaultWorld(); world.revision=Number(body?.world_context?.revision??0); if(body?.world_context?.buildPlot)world.buildPlot=body.world_context.buildPlot;
  return planner.plan(String(body?.prompt??''),world,{nonce:Date.now()});
}
