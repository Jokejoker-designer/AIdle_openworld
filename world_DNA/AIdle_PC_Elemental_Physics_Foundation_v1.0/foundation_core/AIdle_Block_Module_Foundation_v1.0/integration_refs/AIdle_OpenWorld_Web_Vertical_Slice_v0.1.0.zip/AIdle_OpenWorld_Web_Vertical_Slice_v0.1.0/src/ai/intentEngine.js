const rules = [
  { id:'village', words:['làng','village','thị trấn','settlement'] },
  { id:'greenhouse', words:['nhà kính','greenhouse'] },
  { id:'community', words:['trung tâm cộng đồng','community center'] },
  { id:'garden', words:['khu vườn','vườn','garden'] },
  { id:'pond', words:['ao','hồ','pond','lake'] },
  { id:'bridge', words:['cầu','bridge'] },
  { id:'tree', words:['cây','rừng','tree','forest'] },
  { id:'house', words:['ngôi nhà','nhà','house','home'] }
];

export function extractIntent(prompt) {
  const normalized = prompt.toLocaleLowerCase('vi').trim();
  const matches = rules.filter(rule => rule.words.some(word => normalized.includes(word))).map(rule => rule.id);
  const size = /lớn|rộng|big|large/.test(normalized) ? 'large' : /nhỏ|mini|small/.test(normalized) ? 'small' : 'medium';
  const luminous = /đèn|phát sáng|glow|light/.test(normalized);
  const robot = /robot/.test(normalized);
  return { normalized, primary:matches[0] ?? 'unknown', matches, constraints:{ size, luminous, robot } };
}
