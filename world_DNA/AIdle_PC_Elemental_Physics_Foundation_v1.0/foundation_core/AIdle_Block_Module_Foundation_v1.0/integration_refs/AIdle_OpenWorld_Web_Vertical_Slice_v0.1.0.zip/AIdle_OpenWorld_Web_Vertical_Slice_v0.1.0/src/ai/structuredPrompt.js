import { SCHEMA_VERSION, WORLD_STYLE } from '../core/constants.js';

export function createStructuredProposal({ requestId, prompt, revision, entities, summary, cost }) {
  return {
    schema_version: SCHEMA_VERSION,
    request_id: requestId,
    actor: { type:'PLAYER', authority:'PROPOSE_ONLY' },
    operation: 'CREATE',
    target: { world_id:'private_reality_cozy_001', chunk_id:'cozy_center', expected_world_revision:revision },
    style_profile: WORLD_STYLE,
    source_prompt: prompt,
    summary,
    geometry_recipe: entities,
    manifestation: { stages:['WIREFRAME','HOLOGRAM','MATERIALIZING','COMMITTING','COMPLETE'], timing_budget_ms:9000 },
    interaction: { collision_after_complete:true, navigation_after_complete:true },
    budgets: { energy_cost:cost, max_entities:12 },
    provenance: { generator:'DeterministicWorldArchitect', parent_request_id:null },
    preview: { requires_confirmation:true, cancellable_before_commit:true },
    rollback: { allowed:true, mode:'COMPENSATING_MUTATION' }
  };
}
