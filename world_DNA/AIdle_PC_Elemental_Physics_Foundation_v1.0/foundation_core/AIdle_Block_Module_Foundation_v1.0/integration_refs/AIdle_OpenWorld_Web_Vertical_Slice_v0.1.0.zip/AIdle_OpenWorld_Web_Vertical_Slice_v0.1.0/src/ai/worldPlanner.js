import { BUILD_PLOT } from '../core/constants.js';
import { requestId } from '../core/id.js';
import { RECIPE_CATALOG } from '../world/catalog.js';
import { createStructuredProposal } from './structuredPrompt.js';
import { extractIntent } from './intentEngine.js';

function item(recipeId, x, y, index, overrides={}) {
  const recipe = RECIPE_CATALOG[recipeId];
  return { local_id:`proposal_${index}`, recipe_id:recipeId, label:recipe.label, x, y, scale:1, palette:recipe.palette, rotation:0, ...overrides };
}

function planVillage(baseX, baseY) {
  return [
    item('house_small',baseX-2.5,baseY-1.8,0,{scale:.82}), item('house_small',baseX+1.8,baseY-2,1,{scale:.78,palette:'leaf'}),
    item('house_small',baseX-2.2,baseY+1.7,2,{scale:.76,palette:'sky'}), item('path_lamp',baseX,baseY,3),
    item('tree_cluster',baseX+2.6,baseY+1.4,4,{scale:.7}), item('garden_bed',baseX+.1,baseY+1.8,5,{scale:.9})
  ];
}

export class DeterministicWorldArchitect {
  plan(prompt, world, { nonce=Date.now() } = {}) {
    const intent = extractIntent(prompt);
    if (intent.primary === 'unknown') {
      return { ok:false, errors:['Tôi chưa xác định được vật thể có thể xây. Hãy thử nhà kính, khu vườn, ao, cây, cầu hoặc làng nhỏ.'] };
    }
    const cx = world.buildPlot.x + world.buildPlot.width/2;
    const cy = world.buildPlot.y + world.buildPlot.height/2;
    let entities=[]; let summary='';
    switch(intent.primary){
      case 'village': entities=planVillage(cx,cy); summary='Một cụm làng Cozy gồm nhà nhỏ, đường đèn, cây và luống vườn.'; break;
      case 'greenhouse': entities=[item('greenhouse_droplet',cx-1.8,cy-1.3,0,{palette:intent.constraints.luminous?'sky':'leaf', scale:intent.constraints.size==='large'?1.25:intent.constraints.size==='small'?.78:1})]; summary='Nhà kính giọt nước trên khu đất xây dựng, có ánh sáng dịu và không gian cho robot chăm cây.'; break;
      case 'community': entities=[item('community_center',cx-2.5,cy-1.8,0,{scale:intent.constraints.size==='small'?.75:1})]; summary='Một nhà cộng đồng bằng gỗ sáng, phù hợp phong cách Cozy.'; break;
      case 'garden': entities=[item('garden_bed',cx-2.2,cy-1,0),item('garden_bed',cx,cy-1,1),item('garden_bed',cx-1.1,cy+.4,2),item('path_lamp',cx+1.8,cy+.2,3)]; summary='Khu vườn ba luống với đèn lối đi.'; break;
      case 'pond': entities=[item('pond_small',cx-1.5,cy-1,0,{scale:intent.constraints.size==='large'?1.3:1})]; summary='Ao nhỏ có bờ mềm và mặt nước trong.'; break;
      case 'bridge': entities=[item('bridge_wood',cx-1.5,cy-.5,0)]; summary='Cầu gỗ ngắn dùng cho một lối đi trong Starter Realm.'; break;
      case 'tree': entities=[item('tree_cluster',cx-1,cy-1,0,{scale:intent.constraints.size==='large'?1.3:1})]; summary='Cụm cây tán tròn, giữ khoảng trống camera 2.5D.'; break;
      default: entities=[item('house_small',cx-2,cy-1.5,0,{scale:intent.constraints.size==='large'?1.2:1})]; summary='Một ngôi nhà Cozy nhỏ với mái bo mềm.';
    }
    const cost = Math.round(entities.reduce((sum,e)=>sum + RECIPE_CATALOG[e.recipe_id].cost * e.scale,0));
    const id = requestId(prompt, world.revision, nonce);
    return { ok:true, proposal:createStructuredProposal({requestId:id,prompt,revision:world.revision,entities,summary,cost}), intent };
  }
}
