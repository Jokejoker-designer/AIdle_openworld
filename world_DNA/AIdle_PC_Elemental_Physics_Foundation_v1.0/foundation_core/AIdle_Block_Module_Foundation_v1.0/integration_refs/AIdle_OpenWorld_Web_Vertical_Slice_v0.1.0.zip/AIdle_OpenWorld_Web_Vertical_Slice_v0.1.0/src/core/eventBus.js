export class EventBus {
  #listeners = new Map();
  on(event, handler) {
    const list = this.#listeners.get(event) ?? new Set();
    list.add(handler); this.#listeners.set(event, list);
    return () => list.delete(handler);
  }
  emit(event, payload) {
    for (const handler of this.#listeners.get(event) ?? []) handler(payload);
  }
}
