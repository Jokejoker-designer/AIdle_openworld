export function stableHash(input) {
  let hash = 2166136261;
  for (let i = 0; i < input.length; i += 1) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

export function requestId(prompt, revision, nonce = Date.now()) {
  return `req_${stableHash(`${prompt}|${revision}|${nonce}`)}`;
}

export function entityId(requestIdValue, index) {
  return `ent_${stableHash(`${requestIdValue}|${index}`)}`;
}
