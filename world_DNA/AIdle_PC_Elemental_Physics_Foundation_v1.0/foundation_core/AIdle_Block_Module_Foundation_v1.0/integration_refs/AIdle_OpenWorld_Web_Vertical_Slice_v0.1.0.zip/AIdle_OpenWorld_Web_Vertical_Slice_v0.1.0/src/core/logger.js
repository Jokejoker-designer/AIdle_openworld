export class AuditLogger {
  constructor(limit = 200) { this.limit = limit; this.records = []; }
  write(type, payload = {}) {
    const record = { at: new Date().toISOString(), type, payload };
    this.records.push(record);
    if (this.records.length > this.limit) this.records.shift();
    return record;
  }
  snapshot() { return structuredClone(this.records); }
}
