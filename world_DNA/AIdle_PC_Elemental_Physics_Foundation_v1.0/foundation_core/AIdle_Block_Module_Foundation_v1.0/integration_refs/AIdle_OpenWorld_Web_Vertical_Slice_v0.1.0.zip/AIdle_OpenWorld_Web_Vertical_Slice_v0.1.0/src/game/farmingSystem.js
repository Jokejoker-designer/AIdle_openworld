const nextState={empty:'planted',planted:'watered',watered:'grown',grown:'empty'};
const labels={empty:'Trồng hạt',planted:'Tưới cây',watered:'Chờ cây lớn',grown:'Thu hoạch'};
export function farmActionLabel(entity){ return labels[entity.farmState ?? 'empty']; }
export function interactFarm(store, entityId){
  let message='';
  store.update(world=>{
    const entity=world.entities.find(e=>e.id===entityId); if(!entity) return;
    const state=entity.farmState ?? 'empty';
    if(state==='empty'){
      if(world.inventory.seed<=0){ message='Bạn đã hết hạt giống.'; return; }
      world.inventory.seed-=1; entity.farmState='planted'; message='Đã gieo một hạt giống.';
    } else if(state==='planted'){ entity.farmState='watered'; message='Đã tưới. Cây sẽ lớn nhanh trong thế giới thử nghiệm.'; }
    else if(state==='watered'){ entity.farmState='grown'; message='Mầm cây đã phát triển.'; }
    else { world.inventory.harvest+=2; entity.farmState='empty'; message='Thu hoạch được 2 nông sản.'; }
  },'farm');
  store.save(); return message;
}
