export class NPCSystem {
  constructor(){ this.npcs=[
    {id:'nori_7',name:'Nori-7',x:8.3,y:8.1,kind:'robot',phase:0},
    {id:'bui_mo',name:'Bụi Mơ',x:17,y:13,kind:'catbush',phase:1.4},
    {id:'bac_bap',name:'Bác Bắp',x:4.5,y:7.8,kind:'mechanic',phase:2.2}
  ]; }
  update(dt,world){
    for(const npc of this.npcs){ npc.phase+=dt; if(npc.id==='bui_mo'){ npc.x+=Math.cos(npc.phase*.33)*dt*.12; npc.y+=Math.sin(npc.phase*.29)*dt*.09; } }
    const nori=this.npcs[0]; nori.awake=world.flags.noriAwake;
  }
  nearest(player,max=1.7){ let result=null,dist=max; for(const npc of this.npcs){ const d=Math.hypot(player.x-npc.x,player.y-npc.y); if(d<dist){dist=d;result=npc;} } return result; }
  interact(store,npc){
    if(npc.id==='nori_7'){
      const world=store.getState(); if(world.quest.step<1) return 'Nori-7 đang ngủ. Một nhà kính có thể cung cấp nhiệm vụ đầu tiên cho robot.';
      if(!world.flags.noriAwake){ store.update(next=>{next.flags.noriAwake=true;next.quest.step=2;next.quest.complete=true;},'nori-awake'); store.save(); return 'Nori-7 đã kích hoạt! Robot sẽ hỗ trợ chăm sóc cây.'; }
      return 'Nori-7: Mọi luống cây đều ổn. Tôi có thể giúp tưới khi hệ thống Companion được nối API.';
    }
    if(npc.id==='bac_bap') return 'Bác Bắp: Nhà kính tốt cần lối đi rộng và ánh sáng vừa đủ.';
    return 'Bụi Mơ cuộn tròn thành một bụi cây rồi lại ló đầu ra.';
  }
}
