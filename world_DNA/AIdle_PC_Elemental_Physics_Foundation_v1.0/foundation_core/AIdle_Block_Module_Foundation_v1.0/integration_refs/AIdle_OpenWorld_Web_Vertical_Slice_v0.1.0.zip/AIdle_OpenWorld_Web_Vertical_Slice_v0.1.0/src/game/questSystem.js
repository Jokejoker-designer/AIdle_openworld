export function questView(world){
  const step=world.quest.step;
  if(world.quest.complete || step>=2) return {title:'Ngôi nhà kính đầu tiên',description:'Nori-7 đã thức dậy và sẵn sàng chăm sóc khu vườn.',step:2,max:2,label:'2/2 · Hoàn thành'};
  if(step===1) return {title:'Đánh thức Nori-7',description:'Đến gần robot làm vườn và tương tác để kích hoạt.',step:1,max:2,label:'1/2 · Kích hoạt Nori-7'};
  return {title:'Ngôi nhà kính đầu tiên',description:'Dùng AI Architect để tạo một nhà kính trên khu đất phát sáng.',step:0,max:2,label:'0/2 · Tạo nhà kính'};
}
