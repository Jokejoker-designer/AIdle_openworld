export class InputController {
  constructor(){ this.keys=new Set(); this.vector={x:0,y:0}; this.joystick={x:0,y:0}; this.enabled=true; this.#bindKeys(); }
  #bindKeys(){
    addEventListener('keydown',e=>{ if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' ','Tab'].includes(e.key)) e.preventDefault(); this.keys.add(e.key.toLowerCase()); });
    addEventListener('keyup',e=>this.keys.delete(e.key.toLowerCase()));
  }
  update(){
    let x=0,y=0; if(this.enabled){ if(this.keys.has('a')||this.keys.has('arrowleft')) x-=1; if(this.keys.has('d')||this.keys.has('arrowright')) x+=1; if(this.keys.has('w')||this.keys.has('arrowup')) y-=1; if(this.keys.has('s')||this.keys.has('arrowdown')) y+=1; x+=this.joystick.x; y+=this.joystick.y; }
    const len=Math.hypot(x,y)||1; this.vector={x:x/Math.max(1,len),y:y/Math.max(1,len)}; return this.vector;
  }
  setJoystick(x,y){ this.joystick={x,y}; }
}
