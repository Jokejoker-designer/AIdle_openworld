export class AIGatewayClient {
  constructor({ endpoint='/api/ai/plan', fallback }){ this.endpoint=endpoint; this.fallback=fallback; }
  async plan(prompt,world){
    try{
      const response=await fetch(this.endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({prompt,world_context:{revision:world.revision,buildPlot:world.buildPlot}})});
      if(!response.ok) throw new Error(`Gateway ${response.status}`);
      return await response.json();
    }catch(error){ return this.fallback.plan(prompt,world); }
  }
}
