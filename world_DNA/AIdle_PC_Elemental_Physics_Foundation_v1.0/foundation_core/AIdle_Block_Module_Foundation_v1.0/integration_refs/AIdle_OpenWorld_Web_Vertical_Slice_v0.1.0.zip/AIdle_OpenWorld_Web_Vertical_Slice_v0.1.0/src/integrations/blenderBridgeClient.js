export class BlenderBridgeClient {
  constructor({ endpoint='/api/blender' }={}){ this.endpoint=endpoint; }
  async requestGeneratedAsset(spec){
    const response=await fetch(`${this.endpoint}/environment/jobs`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(spec)});
    if(response.status===501) return {status:'UNAVAILABLE',message:'Blender Worker chưa được nối vào web vertical slice.'};
    if(!response.ok) throw new Error(`Blender Bridge ${response.status}`); return response.json();
  }
}
