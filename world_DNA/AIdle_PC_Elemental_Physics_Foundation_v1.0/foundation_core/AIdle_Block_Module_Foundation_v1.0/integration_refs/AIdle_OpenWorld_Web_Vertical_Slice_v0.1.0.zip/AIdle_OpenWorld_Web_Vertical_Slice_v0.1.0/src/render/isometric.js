import { TILE_H, TILE_W } from '../core/constants.js';
export function worldToScreen(x,y,z,camera,viewport){
  return { x:(x-y)*(TILE_W/2)*camera.zoom + viewport.width/2 + camera.x, y:(x+y)*(TILE_H/2)*camera.zoom + viewport.height*.18 + camera.y - z*camera.zoom };
}
export function diamond(ctx,cx,cy,w,h,fill,stroke=null){ ctx.beginPath();ctx.moveTo(cx,cy-h/2);ctx.lineTo(cx+w/2,cy);ctx.lineTo(cx,cy+h/2);ctx.lineTo(cx-w/2,cy);ctx.closePath();ctx.fillStyle=fill;ctx.fill(); if(stroke){ctx.strokeStyle=stroke;ctx.stroke();} }
