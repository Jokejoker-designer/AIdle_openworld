export const RECIPE_CATALOG = Object.freeze({
  greenhouse_droplet: { label:'Nhà kính giọt nước', kind:'building', width:4, depth:3, height:3, cost:35, palette:'leaf', solid:true },
  house_small: { label:'Nhà nhỏ Cozy', kind:'building', width:4, depth:3, height:3, cost:30, palette:'sunset', solid:true },
  garden_bed: { label:'Luống vườn', kind:'farm', width:2, depth:1, height:.25, cost:8, palette:'leaf', solid:false },
  pond_small: { label:'Ao nước nhỏ', kind:'water', width:3, depth:2, height:.1, cost:14, palette:'sky', solid:false },
  tree_cluster: { label:'Cụm cây', kind:'nature', width:2, depth:2, height:4, cost:12, palette:'leaf', solid:true },
  bridge_wood: { label:'Cầu gỗ', kind:'bridge', width:3, depth:1, height:.6, cost:16, palette:'sunset', solid:false },
  path_lamp: { label:'Đèn lối đi', kind:'prop', width:.5, depth:.5, height:1.5, cost:5, palette:'sunset', solid:false },
  community_center: { label:'Nhà cộng đồng', kind:'building', width:6, depth:4, height:4, cost:58, palette:'leaf', solid:true }
});

export const STARTER_ENTITIES = Object.freeze([
  { id:'starter_house', recipeId:'house_small', x:5, y:5, palette:'sunset', committed:true, label:'Nhà khởi đầu' },
  { id:'starter_pond', recipeId:'pond_small', x:18, y:4, palette:'sky', committed:true, label:'Ao nhỏ' },
  { id:'landmark_tree', recipeId:'tree_cluster', x:20, y:13, palette:'leaf', committed:true, label:'Cây landmark', landmark:true },
  { id:'light_brush', recipeId:'path_lamp', x:11, y:14, palette:'sky', committed:true, label:'Trạm Light Brush', interaction:'light_brush' },
  { id:'farm_1', recipeId:'garden_bed', x:4, y:11, palette:'leaf', committed:true, label:'Luống 1', interaction:'farm', farmState:'empty' },
  { id:'farm_2', recipeId:'garden_bed', x:6.2, y:11, palette:'leaf', committed:true, label:'Luống 2', interaction:'farm', farmState:'empty' },
  { id:'farm_3', recipeId:'garden_bed', x:5.1, y:12.3, palette:'leaf', committed:true, label:'Luống 3', interaction:'farm', farmState:'empty' }
]);
