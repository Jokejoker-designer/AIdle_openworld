import { BUILD_PLOT, SCHEMA_VERSION, WORLD_ID, WORLD_STYLE } from '../core/constants.js';
import { STARTER_ENTITIES } from './catalog.js';

export function createDefaultWorld() {
  return {
    schemaVersion: SCHEMA_VERSION,
    worldId: WORLD_ID,
    styleProfile: WORLD_STYLE,
    revision: 0,
    player: { x: 10, y: 10, speed: 3.2, facing:'south', energy:100 },
    camera: { x: 0, y: 0, zoom: 1, quality:'auto', showGrid:false },
    entities: structuredClone(STARTER_ENTITIES),
    preview: null,
    manifestation: null,
    receipts: [],
    history: [],
    processedRequests: {},
    inventory: { seed: 6, fiber: 2, harvest: 0 },
    quest: { id:'quest_greenhouse', step:0, complete:false },
    flags: { noriAwake:false, onboardingSeen:false, reducedMotion:false, buildMode:false },
    buildPlot: structuredClone(BUILD_PLOT),
    lastSavedAt: null,
    audit: []
  };
}
