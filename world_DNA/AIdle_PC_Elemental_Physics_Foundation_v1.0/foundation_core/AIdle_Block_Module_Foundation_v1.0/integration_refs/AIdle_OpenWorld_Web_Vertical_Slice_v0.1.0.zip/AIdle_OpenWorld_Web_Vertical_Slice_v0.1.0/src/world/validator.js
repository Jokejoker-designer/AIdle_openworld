import { WORLD_BOUNDS } from '../core/constants.js';
import { RECIPE_CATALOG } from './catalog.js';

function rectanglesOverlap(a,b){ return a.x < b.x+b.w && a.x+a.w > b.x && a.y < b.y+b.d && a.y+a.d > b.y; }
function rectFor(entity){ const r=RECIPE_CATALOG[entity.recipe_id ?? entity.recipeId]; const s=entity.scale ?? 1; return {x:entity.x,y:entity.y,w:r.width*s,d:r.depth*s}; }

export function validateProposal(proposal, world) {
  const errors=[]; const warnings=[];
  if (!proposal || proposal.schema_version !== '1.1') errors.push('Sai schema version.');
  if (proposal?.target?.expected_world_revision !== world.revision) errors.push('World revision đã thay đổi.');
  const entities=proposal?.geometry_recipe ?? [];
  if (!entities.length) errors.push('Proposal không có vật thể.');
  if (entities.length > 12) errors.push('Proposal vượt giới hạn 12 vật thể của vertical slice.');
  const existing = world.entities.filter(e=>RECIPE_CATALOG[e.recipeId]?.solid).map(rectFor);
  entities.forEach((e,index)=>{
    const recipe=RECIPE_CATALOG[e.recipe_id];
    if (!recipe){ errors.push(`Vật thể ${index+1} dùng recipe không được phép.`); return; }
    const rect=rectFor(e);
    if (rect.x < WORLD_BOUNDS.minX || rect.y < WORLD_BOUNDS.minY || rect.x+rect.w > WORLD_BOUNDS.maxX || rect.y+rect.d > WORLD_BOUNDS.maxY) errors.push(`${recipe.label} nằm ngoài ranh giới.`);
    if (recipe.solid && existing.some(other=>rectanglesOverlap(rect,other))) errors.push(`${recipe.label} va chạm công trình hiện có.`);
  });
  for(let i=0;i<entities.length;i++) for(let j=i+1;j<entities.length;j++){
    const a=RECIPE_CATALOG[entities[i].recipe_id]; const b=RECIPE_CATALOG[entities[j].recipe_id];
    if (a?.solid && b?.solid && rectanglesOverlap(rectFor(entities[i]),rectFor(entities[j]))) errors.push(`${a.label} và ${b.label} chồng lấn.`);
  }
  if (proposal?.budgets?.energy_cost > 160) warnings.push('Kế hoạch khá lớn; có thể giảm kích thước hoặc số vật thể.');
  return { valid:errors.length===0, errors, warnings };
}
