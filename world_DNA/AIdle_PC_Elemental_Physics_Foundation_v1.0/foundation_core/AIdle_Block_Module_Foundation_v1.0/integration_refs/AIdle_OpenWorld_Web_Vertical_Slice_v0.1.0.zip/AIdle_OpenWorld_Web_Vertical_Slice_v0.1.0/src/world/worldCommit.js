import { entityId } from '../core/id.js';
import { validateProposal } from './validator.js';

export class WorldCommitService {
  constructor(store, audit){ this.store=store; this.audit=audit; }
  commit(proposal){
    const world=this.store.getState();
    if (world.processedRequests[proposal.request_id]) return world.processedRequests[proposal.request_id];
    const check=validateProposal(proposal,world); if(!check.valid){ const err=new Error(check.errors.join(' ')); err.code='VALIDATION_FAILED'; throw err; }
    if(proposal.target.expected_world_revision!==world.revision){ const err=new Error('REVISION_CONFLICT'); err.code='REVISION_CONFLICT'; throw err; }
    const ids=proposal.geometry_recipe.map((_,i)=>entityId(proposal.request_id,i));
    const receipt={ receipt_id:`receipt_${proposal.request_id}`, request_id:proposal.request_id, status:'COMPLETE', from_revision:world.revision, to_revision:world.revision+1, entity_ids:ids, committed_at:new Date().toISOString(), provenance:proposal.provenance };
    this.store.update(next=>{
      const entities=proposal.geometry_recipe.map((e,i)=>({ id:ids[i], recipeId:e.recipe_id, x:e.x, y:e.y, scale:e.scale, palette:e.palette, rotation:e.rotation, committed:true, label:e.label, requestId:proposal.request_id }));
      next.entities.push(...entities); next.history.push({ type:'COMMIT', requestId:proposal.request_id, entityIds:ids, proposal:structuredClone(proposal), revision:next.revision+1 });
      next.revision+=1; next.receipts.push(receipt); next.processedRequests[proposal.request_id]=receipt; next.preview=null; next.manifestation=null;
      if(proposal.geometry_recipe.some(e=>e.recipe_id==='greenhouse_droplet')) next.quest.step=Math.max(next.quest.step,1);
    },'commit');
    this.audit?.write('WORLD_COMMIT',receipt); this.store.save(); return receipt;
  }
  undo(){
    const world=this.store.getState(); const last=[...world.history].reverse().find(h=>h.type==='COMMIT' && !h.undone);
    if(!last) return null;
    const receipt={receipt_id:`undo_${last.requestId}_${world.revision+1}`,status:'ROLLED_BACK',compensates:last.requestId,from_revision:world.revision,to_revision:world.revision+1,entity_ids:last.entityIds,committed_at:new Date().toISOString()};
    this.store.update(next=>{
      next.entities=next.entities.filter(e=>!last.entityIds.includes(e.id));
      const original=next.history.find(h=>h.requestId===last.requestId); if(original) original.undone=true;
      next.history.push({type:'UNDO',compensates:last.requestId,entityIds:last.entityIds,revision:next.revision+1}); next.revision+=1; next.receipts.push(receipt);
      if(last.proposal.geometry_recipe.some(e=>e.recipe_id==='greenhouse_droplet')){ next.quest.step=0; next.quest.complete=false; next.flags.noriAwake=false; }
    },'undo');
    this.audit?.write('WORLD_UNDO',receipt); this.store.save(); return receipt;
  }
}
