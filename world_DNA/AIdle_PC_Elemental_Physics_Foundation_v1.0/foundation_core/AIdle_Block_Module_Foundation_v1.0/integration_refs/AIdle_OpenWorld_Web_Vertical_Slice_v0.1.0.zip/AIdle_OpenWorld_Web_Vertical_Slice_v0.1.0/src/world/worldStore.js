import { STORAGE_KEY } from '../core/constants.js';
import { createDefaultWorld } from './defaultWorld.js';

export class MemoryStorage {
  #map = new Map();
  getItem(key){ return this.#map.has(key) ? this.#map.get(key) : null; }
  setItem(key,value){ this.#map.set(key,String(value)); }
  removeItem(key){ this.#map.delete(key); }
}

export class WorldStore {
  constructor({ storage = globalThis.localStorage, key = STORAGE_KEY, initial = null } = {}) {
    this.storage = storage; this.key = key; this.state = initial ?? createDefaultWorld();
    this.listeners = new Set();
  }
  getState(){ return this.state; }
  subscribe(handler){ this.listeners.add(handler); return () => this.listeners.delete(handler); }
  notify(reason='update'){ for (const handler of this.listeners) handler(this.state, reason); }
  update(mutator, reason='update'){
    const next = structuredClone(this.state); mutator(next); this.state = next; this.notify(reason); return next;
  }
  replace(next, reason='replace'){ this.state = structuredClone(next); this.notify(reason); }
  save(){
    const snapshot = structuredClone(this.state); snapshot.lastSavedAt = new Date().toISOString();
    this.state = snapshot; this.storage?.setItem(this.key, JSON.stringify(snapshot)); this.notify('save'); return snapshot;
  }
  load(){
    const raw = this.storage?.getItem(this.key); if (!raw) return null;
    const parsed = JSON.parse(raw); this.replace(parsed,'load'); return parsed;
  }
  reset(){ this.storage?.removeItem(this.key); this.replace(createDefaultWorld(),'reset'); return this.state; }
}
