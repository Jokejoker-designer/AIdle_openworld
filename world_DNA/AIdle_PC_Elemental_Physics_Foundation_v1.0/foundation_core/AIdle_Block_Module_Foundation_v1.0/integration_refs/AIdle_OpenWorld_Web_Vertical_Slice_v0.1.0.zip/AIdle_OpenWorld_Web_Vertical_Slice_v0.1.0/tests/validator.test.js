import test from 'node:test';import assert from 'node:assert/strict';import { DeterministicWorldArchitect } from '../src/ai/worldPlanner.js';import { createDefaultWorld } from '../src/world/defaultWorld.js';import { validateProposal } from '../src/world/validator.js';
const planner=new DeterministicWorldArchitect();
test('valid greenhouse proposal passes',()=>{const w=createDefaultWorld();const p=planner.plan('Tạo nhà kính',w,{nonce:1}).proposal;assert.equal(validateProposal(p,w).valid,true);});
test('revision conflict rejected',()=>{const w=createDefaultWorld();const p=planner.plan('Tạo nhà kính',w,{nonce:1}).proposal;w.revision=2;const r=validateProposal(p,w);assert.equal(r.valid,false);assert.match(r.errors.join(' '),/revision/i);});
test('unknown recipe rejected',()=>{const w=createDefaultWorld();const p=planner.plan('Tạo nhà kính',w,{nonce:1}).proposal;p.geometry_recipe[0].recipe_id='unknown';assert.equal(validateProposal(p,w).valid,false);});
