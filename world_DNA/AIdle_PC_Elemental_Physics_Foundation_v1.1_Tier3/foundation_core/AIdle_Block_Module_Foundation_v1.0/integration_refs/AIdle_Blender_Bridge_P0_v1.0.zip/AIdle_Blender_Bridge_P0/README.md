# AIdle Blender Bridge — P0 Skeleton v1.0

P0 này dựng bộ khung an toàn để **Grok gọi các tool có schema**, còn backend AIdle
mới là bên chạy Blender headless. Grok không nhận tool chạy shell/Python tùy ý.

## P0 chứng minh điều gì?

- FastAPI Bridge khởi động và có `/health`.
- Đọc được Template Registry và Operation Allowlist.
- Request dùng Pydantic v2 với `extra="forbid"`.
- Tạo job idempotent theo `request_id`.
- Runner dựng lệnh Blender bằng argument list, không dùng `shell=True`.
- Blender chạy `--background --factory-startup --disable-autoexec`.
- Worker chỉ chạy `worker_entry.py` do dự án kiểm soát.
- Job lưu stdout, stderr, exit code, receipt và validation trong quarantine.
- Có `mock` mode để test pipeline khi chưa cấu hình Blender.
- Có tool definitions để nối Grok qua function calling/adapter.

## Không thuộc P0

- Chưa dựng Nori-7 hoàn chỉnh.
- Chưa có template `.blend` sản xuất.
- Chưa có rig/animation/LOD thật.
- Chưa có sandbox mạng cấp hệ điều hành. `disable_network` ở P0 là policy marker;
  production cần Windows Firewall, container hoặc worker account bị giới hạn.
- Chưa tự publish asset sang Godot.

## Cấu trúc

```text
app/                    FastAPI bridge
blender_scripts/        entry script được phép chạy trong Blender
config/                 registry, allowlist, limits
examples/               request mẫu
Grok/                   prompt và tool definitions
scripts/                PowerShell setup/smoke/real probe
storage/                jobs, quarantine, evidence
 tests/                  smoke và security tests
```

## Chạy nhanh bằng mock mode

```powershell
cd AIdle_Blender_Bridge_P0
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -e ".[dev]"
Copy-Item .env.example .env
$env:AIDLE_RUNNER_MODE = "mock"
uvicorn app.main:app --host 127.0.0.1 --port 8741
```

Mở terminal khác:

```powershell
Invoke-RestMethod http://127.0.0.1:8741/health
Invoke-RestMethod http://127.0.0.1:8741/v1/templates
```

Gửi probe job:

```powershell
$body = Get-Content examples/p0_probe_request.json -Raw
Invoke-RestMethod -Method Post `
  -Uri http://127.0.0.1:8741/v1/character-jobs `
  -ContentType "application/json" `
  -Body $body
```

## Chạy với Blender thật

1. Cài Blender.
2. Copy `.env.example` thành `.env`.
3. Điền `AIDLE_BLENDER_EXECUTABLE`.
4. Đặt `AIDLE_RUNNER_MODE=real`.
5. Chạy `scripts/run_real_probe.ps1`.

## Test

```powershell
pytest -q
```

## Quy tắc bảo mật chính

- Không có endpoint `/execute-python` hoặc `/run-shell`.
- Không nhận output path từ client.
- Không nhận download URL hoặc add-on URL.
- Job directory do server cấp.
- Template và operation phải có trong registry.
- Build spec nội bộ là file do Bridge sinh, không phải raw request của Grok.
- Template source không bị sửa; output chỉ vào `storage/`.
