from fastapi import APIRouter

from app import __version__
from app.config import get_settings
from app.dependencies import get_blender_runner, get_operation_policy, get_template_registry
from app.models import HealthResponse

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    settings = get_settings()
    runner = get_blender_runner()
    return HealthResponse(
        service=settings.app_name,
        version=__version__,
        status="ok",
        runner_mode=settings.runner_mode,
        blender_executable=str(settings.blender_executable),
        blender_available=runner.blender_available(),
        template_count=len(get_template_registry()),
        operation_profile_count=len(get_operation_policy()),
        network_policy_marker=settings.disable_network,
    )
