from fastapi import APIRouter, BackgroundTasks, HTTPException

from app.dependencies import get_job_service, get_job_store
from app.models import CharacterJobRequest, JobReceipt
from app.services.job_service import DuplicateRequestError

router = APIRouter(prefix="/v1/character-jobs", tags=["character-jobs"])


@router.post("", response_model=JobReceipt, status_code=202)
def create_job(request: CharacterJobRequest, background_tasks: BackgroundTasks) -> JobReceipt:
    service = get_job_service()
    try:
        receipt = service.create(request)
    except DuplicateRequestError as exc:
        raise HTTPException(
            status_code=409,
            detail={
                "message": str(exc),
                "existing_job_id": exc.receipt.job_id,
                "existing_state": exc.receipt.state,
            },
        ) from exc
    except KeyError as exc:
        raise HTTPException(status_code=422, detail=f"Unknown registry identifier: {exc.args[0]}") from exc
    background_tasks.add_task(service.execute, receipt.job_id)
    return receipt


@router.get("/{job_id}", response_model=JobReceipt)
def get_job(job_id: str) -> JobReceipt:
    try:
        return get_job_service().get(job_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Unknown job_id") from exc


@router.post("/{job_id}/cancel", response_model=JobReceipt)
def cancel_job(job_id: str) -> JobReceipt:
    try:
        return get_job_store().cancel_if_queued(job_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Unknown job_id") from exc
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
