from fastapi import APIRouter, HTTPException

from app.dependencies import get_template_registry

router = APIRouter(prefix="/v1/templates", tags=["templates"])


@router.get("")
def list_templates() -> dict:
    return {"templates": get_template_registry().list()}


@router.get("/{template_id}")
def get_template(template_id: str) -> dict:
    try:
        record = get_template_registry().get(template_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Unknown template_id") from exc
    return {"template_id": record.template_id, **record.data}
