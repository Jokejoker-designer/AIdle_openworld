from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=PROJECT_ROOT / ".env",
        env_prefix="AIDLE_",
        extra="ignore",
    )

    app_name: str = "AIdle Blender Bridge P0"
    host: str = "127.0.0.1"
    port: int = 8741
    runner_mode: str = Field(default="mock", pattern="^(mock|real)$")
    blender_executable: Path = Path("blender")
    job_timeout_seconds: int = Field(default=180, ge=10, le=3600)
    max_active_jobs: int = Field(default=1, ge=1, le=8)
    disable_network: bool = True
    log_level: str = "INFO"

    project_root: Path = PROJECT_ROOT
    config_root: Path = PROJECT_ROOT / "config"
    scripts_root: Path = PROJECT_ROOT / "blender_scripts"
    storage_root: Path = PROJECT_ROOT / "storage"
    jobs_root: Path = PROJECT_ROOT / "storage" / "jobs"
    quarantine_root: Path = PROJECT_ROOT / "storage" / "generated_quarantine"
    evidence_root: Path = PROJECT_ROOT / "storage" / "evidence"
    rejected_root: Path = PROJECT_ROOT / "storage" / "rejected"

    def ensure_directories(self) -> None:
        for path in (
            self.jobs_root,
            self.quarantine_root,
            self.evidence_root,
            self.rejected_root,
        ):
            path.mkdir(parents=True, exist_ok=True)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    settings = Settings()
    settings.ensure_directories()
    return settings
