from __future__ import annotations

from functools import lru_cache

from app.config import get_settings
from app.services.blender_runner import BlenderRunner
from app.services.job_service import CharacterJobService
from app.services.job_store import JobStore
from app.services.operation_policy import OperationPolicy
from app.services.template_registry import TemplateRegistry


@lru_cache(maxsize=1)
def get_template_registry() -> TemplateRegistry:
    settings = get_settings()
    return TemplateRegistry(settings.config_root / "templates.yaml")


@lru_cache(maxsize=1)
def get_operation_policy() -> OperationPolicy:
    settings = get_settings()
    return OperationPolicy(settings.config_root / "operation_allowlist.yaml")


@lru_cache(maxsize=1)
def get_job_store() -> JobStore:
    return JobStore(get_settings().jobs_root)


@lru_cache(maxsize=1)
def get_blender_runner() -> BlenderRunner:
    return BlenderRunner(get_settings())


@lru_cache(maxsize=1)
def get_job_service() -> CharacterJobService:
    return CharacterJobService(
        settings=get_settings(),
        templates=get_template_registry(),
        operations=get_operation_policy(),
        store=get_job_store(),
        runner=get_blender_runner(),
    )
