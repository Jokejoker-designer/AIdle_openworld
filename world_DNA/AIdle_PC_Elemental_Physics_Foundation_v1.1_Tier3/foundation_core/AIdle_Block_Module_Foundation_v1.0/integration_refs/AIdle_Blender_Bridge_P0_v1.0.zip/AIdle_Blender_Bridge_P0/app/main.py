from __future__ import annotations

import logging

from fastapi import FastAPI

from app.api.health import router as health_router
from app.api.jobs import router as jobs_router
from app.api.templates import router as templates_router
from app.config import get_settings

settings = get_settings()
logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))

app = FastAPI(
    title="AIdle Blender Bridge P0",
    version="1.0.0",
    docs_url="/docs",
    redoc_url=None,
)
app.include_router(health_router)
app.include_router(templates_router)
app.include_router(jobs_router)
