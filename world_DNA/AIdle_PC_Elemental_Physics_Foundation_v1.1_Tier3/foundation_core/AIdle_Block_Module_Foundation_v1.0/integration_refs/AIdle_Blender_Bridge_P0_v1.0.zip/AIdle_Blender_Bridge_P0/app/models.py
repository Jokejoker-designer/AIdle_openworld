from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class OutputRequest(StrictModel):
    save_blend: bool = True
    export_glb: bool = True
    render_preview: bool = True
    generate_validation_report: bool = True


class CharacterJobRequest(StrictModel):
    schema_version: Literal["1.0"] = "1.0"
    request_id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{2,63}$")
    character_id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{2,63}$")
    display_name: str = Field(min_length=1, max_length=80)
    template_id: str = Field(pattern=r"^[a-z0-9][a-z0-9_-]{2,63}$")
    operation_profile: str = Field(default="p0_probe", pattern=r"^[a-z0-9_-]{2,63}$")
    outputs: OutputRequest = OutputRequest()


class JobState(StrEnum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    QUARANTINED_COMPLETE = "QUARANTINED_COMPLETE"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class JobReceipt(StrictModel):
    job_id: str
    request_id: str
    character_id: str
    template_id: str
    operation_profile: str
    state: JobState
    runner_mode: Literal["mock", "real"]
    output_zone: Literal["generated_quarantine"] = "generated_quarantine"
    created_at: datetime
    updated_at: datetime
    exit_code: int | None = None
    artifacts: list[str] = []
    error: str | None = None


class HealthResponse(StrictModel):
    service: str
    version: str
    status: Literal["ok"]
    runner_mode: Literal["mock", "real"]
    blender_executable: str
    blender_available: bool
    template_count: int
    operation_profile_count: int
    network_policy_marker: bool
