from __future__ import annotations

from pathlib import Path


class PathPolicyError(ValueError):
    pass


def resolve_within(root: Path, candidate: Path) -> Path:
    root_resolved = root.resolve()
    candidate_resolved = candidate.resolve()
    if candidate_resolved != root_resolved and root_resolved not in candidate_resolved.parents:
        raise PathPolicyError(f"Path escapes approved root: {candidate_resolved}")
    return candidate_resolved


def safe_child(root: Path, name: str) -> Path:
    if not name or any(part in name for part in ("/", "\\", "..")):
        raise PathPolicyError("Unsafe path component")
    return resolve_within(root, root / name)
