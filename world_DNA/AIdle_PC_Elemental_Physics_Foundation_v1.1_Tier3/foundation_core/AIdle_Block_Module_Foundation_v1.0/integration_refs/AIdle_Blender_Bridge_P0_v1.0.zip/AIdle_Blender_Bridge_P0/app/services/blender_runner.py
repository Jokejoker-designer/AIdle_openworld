from __future__ import annotations

import json
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from app.config import Settings
from app.security.path_policy import resolve_within


@dataclass(frozen=True)
class RunnerResult:
    exit_code: int
    artifacts: list[str]
    error: str | None = None


class BlenderRunner:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def blender_available(self) -> bool:
        configured = str(self.settings.blender_executable)
        return Path(configured).exists() or shutil.which(configured) is not None

    def build_command(self, build_spec_path: Path, job_dir: Path) -> list[str]:
        build_spec_path = resolve_within(self.settings.jobs_root, build_spec_path)
        job_dir = resolve_within(self.settings.jobs_root, job_dir)
        worker_entry = resolve_within(
            self.settings.scripts_root,
            self.settings.scripts_root / "worker_entry.py",
        )
        return [
            str(self.settings.blender_executable),
            "--background",
            "--factory-startup",
            "--disable-autoexec",
            "--python-exit-code",
            "20",
            "--python",
            str(worker_entry),
            "--",
            str(build_spec_path),
            str(job_dir),
        ]

    def run(self, build_spec_path: Path, job_dir: Path) -> RunnerResult:
        if self.settings.runner_mode == "mock":
            return self._run_mock(build_spec_path, job_dir)
        return self._run_real(build_spec_path, job_dir)

    def _artifact_ref(self, path: Path) -> str:
        relative = path.resolve().relative_to(self.settings.quarantine_root.resolve())
        return str(Path("generated_quarantine") / relative).replace("\\", "/")

    def _run_mock(self, build_spec_path: Path, job_dir: Path) -> RunnerResult:
        spec = json.loads(build_spec_path.read_text(encoding="utf-8"))
        quarantine_dir = Path(spec["server_output_dir"])
        quarantine_dir.mkdir(parents=True, exist_ok=True)
        artifacts: list[str] = []
        for name, content in (
            ("p0_probe.blend.mock", "mock blend artifact\n"),
            ("p0_probe.glb.mock", "mock glb artifact\n"),
            ("p0_probe_preview.png.mock", "mock preview artifact\n"),
        ):
            path = quarantine_dir / name
            path.write_text(content, encoding="utf-8")
            artifacts.append(self._artifact_ref(path))
        validation = {
            "passed": True,
            "runner_mode": "mock",
            "character_id": spec["character_id"],
            "checks": {
                "schema": "PASS",
                "template": "PASS",
                "operation_profile": "PASS",
                "quarantine_only": "PASS",
            },
        }
        validation_path = quarantine_dir / "validation.json"
        validation_path.write_text(json.dumps(validation, indent=2) + "\n", encoding="utf-8")
        artifacts.append(self._artifact_ref(validation_path))
        (job_dir / "worker_stdout.log").write_text("P0 mock worker completed\n", encoding="utf-8")
        (job_dir / "worker_stderr.log").write_text("", encoding="utf-8")
        (job_dir / "blender_exit_code.txt").write_text("0\n", encoding="utf-8")
        return RunnerResult(exit_code=0, artifacts=artifacts)

    def _run_real(self, build_spec_path: Path, job_dir: Path) -> RunnerResult:
        if not self.blender_available():
            return RunnerResult(exit_code=127, artifacts=[], error="Blender executable not found")

        command = self.build_command(build_spec_path, job_dir)
        (job_dir / "blender_command.json").write_text(
            json.dumps(command, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        env = {
            "PATH": os.environ.get("PATH", ""),
            "SYSTEMROOT": os.environ.get("SYSTEMROOT", ""),
            "TEMP": os.environ.get("TEMP", str(job_dir)),
            "TMP": os.environ.get("TMP", str(job_dir)),
            "AIDLE_ALLOWED_JOB_ROOT": str(self.settings.jobs_root.resolve()),
            "AIDLE_ALLOWED_QUARANTINE_ROOT": str(self.settings.quarantine_root.resolve()),
            "AIDLE_NETWORK_POLICY": "deny" if self.settings.disable_network else "unspecified",
        }
        try:
            completed = subprocess.run(
                command,
                cwd=self.settings.project_root,
                env=env,
                stdin=subprocess.DEVNULL,
                capture_output=True,
                text=True,
                timeout=self.settings.job_timeout_seconds,
                shell=False,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            (job_dir / "worker_stdout.log").write_text(exc.stdout or "", encoding="utf-8")
            (job_dir / "worker_stderr.log").write_text(exc.stderr or "timeout\n", encoding="utf-8")
            (job_dir / "blender_exit_code.txt").write_text("124\n", encoding="utf-8")
            return RunnerResult(exit_code=124, artifacts=[], error="Blender job timed out")

        (job_dir / "worker_stdout.log").write_text(completed.stdout or "", encoding="utf-8")
        (job_dir / "worker_stderr.log").write_text(completed.stderr or "", encoding="utf-8")
        (job_dir / "blender_exit_code.txt").write_text(f"{completed.returncode}\n", encoding="utf-8")

        spec = json.loads(build_spec_path.read_text(encoding="utf-8"))
        quarantine_dir = Path(spec["server_output_dir"])
        artifacts = [
            self._artifact_ref(path)
            for path in quarantine_dir.glob("*")
            if path.is_file()
        ]
        error = None if completed.returncode == 0 else "Blender worker failed"
        return RunnerResult(exit_code=completed.returncode, artifacts=sorted(artifacts), error=error)
