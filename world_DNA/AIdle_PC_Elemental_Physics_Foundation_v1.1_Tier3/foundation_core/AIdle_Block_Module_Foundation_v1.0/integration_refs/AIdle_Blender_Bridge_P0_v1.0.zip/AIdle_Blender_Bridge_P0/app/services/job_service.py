from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from app.config import Settings
from app.models import CharacterJobRequest, JobReceipt, JobState
from app.security.path_policy import safe_child
from app.services.blender_runner import BlenderRunner
from app.services.job_store import JobStore
from app.services.operation_policy import OperationPolicy
from app.services.template_registry import TemplateRegistry


class DuplicateRequestError(ValueError):
    def __init__(self, receipt: JobReceipt) -> None:
        self.receipt = receipt
        super().__init__(f"Duplicate request_id: {receipt.request_id}")


class CharacterJobService:
    def __init__(
        self,
        settings: Settings,
        templates: TemplateRegistry,
        operations: OperationPolicy,
        store: JobStore,
        runner: BlenderRunner,
    ) -> None:
        self.settings = settings
        self.templates = templates
        self.operations = operations
        self.store = store
        self.runner = runner

    def create(self, request: CharacterJobRequest) -> JobReceipt:
        existing = self.store.find_by_request_id(request.request_id)
        if existing is not None:
            raise DuplicateRequestError(existing)

        template = self.templates.get(request.template_id)
        profile = self.operations.get_profile(request.operation_profile)

        job_id = "BLD-" + uuid.uuid4().hex[:12].upper()
        job_dir = self.store.job_dir(job_id)
        quarantine_dir = safe_child(self.settings.quarantine_root, job_id)
        quarantine_dir.mkdir(parents=True, exist_ok=False)

        now = datetime.now(timezone.utc)
        receipt = JobReceipt(
            job_id=job_id,
            request_id=request.request_id,
            character_id=request.character_id,
            template_id=request.template_id,
            operation_profile=request.operation_profile,
            state=JobState.QUEUED,
            runner_mode=self.settings.runner_mode,
            created_at=now,
            updated_at=now,
        )
        self.store.write_receipt(receipt)

        internal_spec = {
            "schema_version": "1.0",
            "job_id": job_id,
            "request_id": request.request_id,
            "character_id": request.character_id,
            "display_name": request.display_name,
            "template_id": request.template_id,
            "template_capabilities": template.data,
            "operation_profile": request.operation_profile,
            "allowed_operations": profile.get("allowed_operations", []),
            "outputs": request.outputs.model_dump(),
            "server_output_dir": str(quarantine_dir.resolve()),
            "policy": {
                "allow_external_paths": False,
                "allow_network": False,
                "allow_embedded_scripts": False,
            },
        }
        spec_path = job_dir / "build_spec.internal.json"
        spec_path.write_text(json.dumps(internal_spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (job_dir / "request.sha256").write_text(
            hashlib.sha256(request.model_dump_json().encode("utf-8")).hexdigest().upper() + "\n",
            encoding="utf-8",
        )
        return receipt

    def execute(self, job_id: str) -> JobReceipt:
        receipt = self.store.read_receipt(job_id)
        if receipt.state == JobState.CANCELLED:
            return receipt
        self.store.update(job_id, state=JobState.RUNNING)
        job_dir = self.store.job_dir(job_id)
        result = self.runner.run(job_dir / "build_spec.internal.json", job_dir)
        if result.exit_code == 0:
            return self.store.update(
                job_id,
                state=JobState.QUARANTINED_COMPLETE,
                exit_code=0,
                artifacts=result.artifacts,
            )
        return self.store.update(
            job_id,
            state=JobState.FAILED,
            exit_code=result.exit_code,
            artifacts=result.artifacts,
            error=result.error,
        )

    def get(self, job_id: str) -> JobReceipt:
        return self.store.read_receipt(job_id)
