from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from app.models import JobReceipt, JobState
from app.security.path_policy import safe_child


class JobStore:
    def __init__(self, jobs_root: Path) -> None:
        self.jobs_root = jobs_root
        self.jobs_root.mkdir(parents=True, exist_ok=True)

    def job_dir(self, job_id: str) -> Path:
        path = safe_child(self.jobs_root, job_id)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def receipt_path(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "job_receipt.json"

    def write_receipt(self, receipt: JobReceipt) -> None:
        path = self.receipt_path(receipt.job_id)
        payload = receipt.model_dump(mode="json")
        fd, temp_name = tempfile.mkstemp(prefix="receipt_", suffix=".json", dir=path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
            os.replace(temp_name, path)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)

    def read_receipt(self, job_id: str) -> JobReceipt:
        path = self.receipt_path(job_id)
        if not path.exists():
            raise KeyError(job_id)
        return JobReceipt.model_validate_json(path.read_text(encoding="utf-8"))

    def update(self, job_id: str, **changes: object) -> JobReceipt:
        receipt = self.read_receipt(job_id)
        data = receipt.model_dump()
        data.update(changes)
        data["updated_at"] = datetime.now(timezone.utc)
        updated = JobReceipt.model_validate(data)
        self.write_receipt(updated)
        return updated

    def find_by_request_id(self, request_id: str) -> JobReceipt | None:
        for path in self.jobs_root.glob("*/job_receipt.json"):
            try:
                receipt = JobReceipt.model_validate_json(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if receipt.request_id == request_id:
                return receipt
        return None

    def cancel_if_queued(self, job_id: str) -> JobReceipt:
        receipt = self.read_receipt(job_id)
        if receipt.state != JobState.QUEUED:
            raise ValueError("Only queued jobs can be cancelled in P0")
        return self.update(job_id, state=JobState.CANCELLED)
