from __future__ import annotations

from pathlib import Path
from typing import Any

from app.services.yaml_loader import load_yaml


class OperationPolicy:
    def __init__(self, path: Path) -> None:
        raw = load_yaml(path)
        profiles = raw.get("profiles", {})
        denied = raw.get("globally_denied", [])
        if not isinstance(profiles, dict) or not isinstance(denied, list):
            raise ValueError("Invalid operation policy")
        self._profiles: dict[str, Any] = profiles
        self.globally_denied = frozenset(str(item) for item in denied)

    def get_profile(self, profile_id: str) -> dict[str, Any]:
        value = self._profiles.get(profile_id)
        if value is None:
            raise KeyError(profile_id)
        operations = value.get("allowed_operations", [])
        if self.globally_denied.intersection(operations):
            raise ValueError("Operation profile includes a globally denied operation")
        return value

    def list_profiles(self) -> list[str]:
        return sorted(self._profiles)

    def __len__(self) -> int:
        return len(self._profiles)
