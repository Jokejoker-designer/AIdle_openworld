from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from app.services.yaml_loader import load_yaml


@dataclass(frozen=True)
class TemplateRecord:
    template_id: str
    data: dict[str, Any]


class TemplateRegistry:
    def __init__(self, path: Path) -> None:
        self.path = path
        raw = load_yaml(path)
        templates = raw.get("templates", {})
        if not isinstance(templates, dict):
            raise ValueError("templates must be a mapping")
        self._templates = templates

    def list(self) -> list[dict[str, Any]]:
        return [dict(template_id=key, **value) for key, value in sorted(self._templates.items())]

    def get(self, template_id: str) -> TemplateRecord:
        value = self._templates.get(template_id)
        if value is None:
            raise KeyError(template_id)
        return TemplateRecord(template_id=template_id, data=value)

    def __len__(self) -> int:
        return len(self._templates)
