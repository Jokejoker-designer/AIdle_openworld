"""Approved Blender entry script for the P0 probe.

This file is executed by Blender, not by the FastAPI Python environment.
It intentionally uses only Python stdlib + bpy and accepts only server-generated paths.
"""
from __future__ import annotations

import json
import math
import os
import sys
from pathlib import Path

import bpy


def _resolve_within(root: Path, candidate: Path) -> Path:
    root = root.resolve()
    candidate = candidate.resolve()
    if candidate != root and root not in candidate.parents:
        raise PermissionError(f"Path escapes approved root: {candidate}")
    return candidate


def _args() -> tuple[Path, Path]:
    if "--" not in sys.argv:
        raise RuntimeError("Missing worker arguments")
    values = sys.argv[sys.argv.index("--") + 1 :]
    if len(values) != 2:
        raise RuntimeError("Expected build_spec_path and job_dir")
    jobs_root = Path(os.environ["AIDLE_ALLOWED_JOB_ROOT"])
    return (
        _resolve_within(jobs_root, Path(values[0])),
        _resolve_within(jobs_root, Path(values[1])),
    )


def _clear_scene() -> None:
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.cameras, bpy.data.lights):
        for block in list(datablocks):
            if block.users == 0:
                datablocks.remove(block)


def _material(name: str, rgba: tuple[float, float, float, float]):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = rgba
    mat.use_nodes = True
    principled = mat.node_tree.nodes.get("Principled BSDF")
    if principled:
        principled.inputs["Base Color"].default_value = rgba
        principled.inputs["Roughness"].default_value = 0.65
    return mat


def _add_uv_sphere(name: str, location, scale, material) -> bpy.types.Object:
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(material)
    return obj


def _add_cube(name: str, location, scale, material, bevel: float = 0.12) -> bpy.types.Object:
    bpy.ops.mesh.primitive_cube_add(location=location)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bevel_mod = obj.modifiers.new("P0_Bevel", "BEVEL")
    bevel_mod.width = bevel
    bevel_mod.segments = 2
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_apply(modifier=bevel_mod.name)
    obj.data.materials.append(material)
    return obj


def _build_probe() -> list[bpy.types.Object]:
    cream = _material("MAT_CreamCeramic", (0.82, 0.72, 0.52, 1.0))
    green = _material("MAT_LeafGreen", (0.12, 0.48, 0.18, 1.0))
    cyan = _material("MAT_CyanDisplay", (0.05, 0.65, 0.85, 1.0))

    objects = [
        _add_uv_sphere("P0_Body", (0, 0, 1.15), (0.72, 0.58, 0.82), cream),
        _add_cube("P0_Leg_L", (-0.28, 0, 0.38), (0.18, 0.22, 0.38), green),
        _add_cube("P0_Leg_R", (0.28, 0, 0.38), (0.18, 0.22, 0.38), green),
        _add_cube("P0_Display", (0, -0.54, 1.28), (0.32, 0.05, 0.18), cyan, 0.06),
        _add_cube("P0_SproutStem", (0, 0, 2.02), (0.05, 0.05, 0.26), green, 0.03),
        _add_uv_sphere("P0_SproutLeaf", (0.18, 0, 2.27), (0.24, 0.08, 0.11), green),
    ]
    for obj in objects:
        obj["aidle_p0_probe"] = True
    return objects


def _setup_render() -> None:
    bpy.ops.object.camera_add(location=(4.2, -5.2, 3.5))
    camera = bpy.context.object
    camera.name = "P0_Camera"
    bpy.context.scene.camera = camera

    direction = (0.0, 0.0, 1.05)
    dx = direction[0] - camera.location.x
    dy = direction[1] - camera.location.y
    dz = direction[2] - camera.location.z
    camera.rotation_euler = (math.atan2((dx * dx + dy * dy) ** 0.5, dz), 0.0, math.atan2(dy, dx) - math.pi / 2)
    camera.data.type = "ORTHO"
    camera.data.ortho_scale = 3.4

    bpy.ops.object.light_add(type="AREA", location=(3.0, -3.0, 5.0))
    key = bpy.context.object
    key.name = "P0_KeyLight"
    key.data.energy = 900
    key.data.shape = "DISK"
    key.data.size = 4

    bpy.ops.object.light_add(type="AREA", location=(-3.0, -1.0, 2.5))
    fill = bpy.context.object
    fill.name = "P0_FillLight"
    fill.data.energy = 450
    fill.data.size = 3

    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.render.resolution_x = 512
    scene.render.resolution_y = 512
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.world.color = (0.045, 0.055, 0.07)


def _triangles() -> int:
    depsgraph = bpy.context.evaluated_depsgraph_get()
    total = 0
    for obj in bpy.context.scene.objects:
        if obj.type != "MESH":
            continue
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        mesh.calc_loop_triangles()
        total += len(mesh.loop_triangles)
        evaluated.to_mesh_clear()
    return total


def main() -> None:
    spec_path, job_dir = _args()
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    quarantine_root = Path(os.environ["AIDLE_ALLOWED_QUARANTINE_ROOT"])
    output_dir = _resolve_within(quarantine_root, Path(spec["server_output_dir"]))
    output_dir.mkdir(parents=True, exist_ok=True)

    required = {
        "create_probe_scene",
        "save_blend",
        "export_glb",
        "write_validation_report",
    }
    allowed = set(spec["allowed_operations"])
    missing = required - allowed
    if missing:
        raise PermissionError(f"Missing required approved operations: {sorted(missing)}")

    _clear_scene()
    objects = _build_probe()
    _setup_render()

    artifacts = []
    if spec["outputs"].get("save_blend", True):
        blend_path = output_dir / "p0_probe.blend"
        bpy.ops.wm.save_as_mainfile(filepath=str(blend_path), check_existing=False)
        artifacts.append(blend_path.name)

    if spec["outputs"].get("export_glb", True):
        glb_path = output_dir / "p0_probe.glb"
        bpy.ops.export_scene.gltf(
            filepath=str(glb_path),
            export_format="GLB",
            export_apply=True,
        )
        artifacts.append(glb_path.name)

    if spec["outputs"].get("render_preview", True):
        preview_path = output_dir / "p0_probe_preview.png"
        bpy.context.scene.render.filepath = str(preview_path)
        bpy.ops.render.render(write_still=True)
        artifacts.append(preview_path.name)

    validation = {
        "passed": True,
        "runner_mode": "real",
        "job_id": spec["job_id"],
        "character_id": spec["character_id"],
        "template_id": spec["template_id"],
        "object_count": len(objects),
        "triangle_count": _triangles(),
        "artifacts": artifacts,
        "network_policy_marker": os.environ.get("AIDLE_NETWORK_POLICY", "unknown"),
        "checks": {
            "approved_entry_script": "PASS",
            "quarantine_path": "PASS",
            "autoexec_disabled_by_runner": "PASS",
            "glb_export": "PASS" if "p0_probe.glb" in artifacts else "SKIP",
        },
    }
    validation_path = output_dir / "validation.json"
    validation_path.write_text(json.dumps(validation, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"event": "P0_WORKER_COMPLETE", "validation": validation}, ensure_ascii=False))


if __name__ == "__main__":
    main()
