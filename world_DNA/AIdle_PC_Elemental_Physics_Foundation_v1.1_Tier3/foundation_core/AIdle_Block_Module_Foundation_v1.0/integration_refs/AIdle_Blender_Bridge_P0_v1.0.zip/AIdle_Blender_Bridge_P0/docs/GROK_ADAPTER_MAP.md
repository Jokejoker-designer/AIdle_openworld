# Grok Tool → Bridge Endpoint Map

| Grok tool | Bridge action |
|---|---|
| `inspect_character_template` | `GET /v1/templates/{template_id}` |
| `build_character_from_template` | `POST /v1/character-jobs` |
| `get_character_job_status` | `GET /v1/character-jobs/{job_id}` |

Adapter chịu trách nhiệm giữ base URL và auth. Grok không được nhìn thấy API key,
Blender executable path, job filesystem path hoặc server output path.
