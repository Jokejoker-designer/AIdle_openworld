# P0 Acceptance Checklist

## Bridge

- [ ] `GET /health` trả `status=ok`.
- [ ] Template registry có `p0_probe_empty_scene`.
- [ ] Operation registry có `p0_probe`.
- [ ] Unknown template bị từ chối 422.
- [ ] Extra JSON property bị từ chối 422.
- [ ] Duplicate `request_id` bị từ chối 409.
- [ ] Client không truyền được output path.

## Runner

- [ ] Command dùng argument list, `shell=False`.
- [ ] Có `--background`.
- [ ] Có `--factory-startup`.
- [ ] Có `--disable-autoexec`.
- [ ] Có `--python-exit-code 20`.
- [ ] Worker entry nằm trong repo.
- [ ] stdout/stderr/exit code được lưu.

## Real Blender probe

- [ ] Sinh `p0_probe.blend`.
- [ ] Sinh `p0_probe.glb`.
- [ ] Sinh `p0_probe_preview.png`.
- [ ] Sinh `validation.json`.
- [ ] Tất cả output nằm trong `storage/generated_quarantine/<job_id>`.
- [ ] Không copy sang Godot.

## Review

- [ ] QA evidence bundle.
- [ ] Red review.
- [ ] Purple verification.
- [ ] Codex machine acceptance.
