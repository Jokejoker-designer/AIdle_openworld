# Security Boundary — P0

## Đã khóa

- Strict request schema.
- Registry-only template/profile.
- Server-generated job/output paths.
- No arbitrary Python/shell endpoints.
- No add-on/download fields.
- `shell=False`.
- Blender `--disable-autoexec`.
- Worker entry hashable and repository-owned.
- Quarantine-only output.

## Chưa phải sandbox hoàn chỉnh

Biến `AIDLE_DISABLE_NETWORK=true` chỉ biểu thị policy trong P0. Python chạy trong
Blender vẫn có quyền của OS account. Production phải bổ sung:

- Worker OS account riêng.
- NTFS ACL chỉ cho template read và job/quarantine write.
- Windows Firewall outbound deny cho `blender.exe` hoặc container network deny.
- Process/job object resource limits.
- Template/part SHA-256 registry.
- Antivirus/malware scanning đối với input ngoài.
- No user-uploaded `.blend` in trusted worker.
