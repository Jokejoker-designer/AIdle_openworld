# P0 Test Report

## Automated verification

- `pytest -q`: **9 passed**
- `python -m compileall -q app tests`: **PASS**
- FastAPI import/title/version smoke: **PASS**
- Mock end-to-end job: **QUARANTINED_COMPLETE**

## Covered

- Health endpoint.
- Template registry.
- Strict request schema rejects arbitrary fields.
- Unknown template rejection.
- Idempotent duplicate request rejection.
- Mock job artifacts and validation receipt.
- Path traversal rejection.
- Blender command contains background/factory/autoexec/python-exit flags.

## Not verified in this build environment

- Real Blender executable invocation.
- Real `.blend`, `.glb` and PNG generation.
- Blender version-specific Eevee/export behavior.
- OS-level outbound network denial.

Run `scripts/run_real_probe.ps1` on the target Windows workstation after setting
`AIDLE_BLENDER_EXECUTABLE` and `AIDLE_RUNNER_MODE=real`.
