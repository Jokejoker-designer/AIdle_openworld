$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
& .\.venv\Scripts\Activate.ps1
$env:AIDLE_RUNNER_MODE = "real"

$Health = Invoke-RestMethod "http://127.0.0.1:8741/health"
if (-not $Health.blender_available) {
    throw "Blender executable not found. Set AIDLE_BLENDER_EXECUTABLE in .env."
}

$Request = Get-Content "examples/p0_probe_request.json" -Raw | ConvertFrom-Json
$Request.request_id = "p0-real-" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$Body = $Request | ConvertTo-Json -Depth 8
$Job = Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8741/v1/character-jobs" `
  -ContentType "application/json" -Body $Body

for ($i = 0; $i -lt 120; $i++) {
    Start-Sleep -Seconds 1
    $Final = Invoke-RestMethod "http://127.0.0.1:8741/v1/character-jobs/$($Job.job_id)"
    if ($Final.state -in @("QUARANTINED_COMPLETE", "FAILED", "CANCELLED")) { break }
}
$Final | ConvertTo-Json -Depth 8
if ($Final.state -ne "QUARANTINED_COMPLETE") { throw "Real Blender probe failed" }
