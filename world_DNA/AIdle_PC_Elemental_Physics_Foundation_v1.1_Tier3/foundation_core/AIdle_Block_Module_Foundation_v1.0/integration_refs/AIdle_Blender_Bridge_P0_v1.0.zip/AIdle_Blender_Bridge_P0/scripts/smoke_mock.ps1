$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
& .\.venv\Scripts\Activate.ps1
$env:AIDLE_RUNNER_MODE = "mock"

$Process = Start-Process -PassThru -WindowStyle Hidden -FilePath ".\.venv\Scripts\python.exe" `
  -ArgumentList "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8741"
try {
    Start-Sleep -Seconds 2
    $Health = Invoke-RestMethod "http://127.0.0.1:8741/health"
    $Body = Get-Content "examples/p0_probe_request.json" -Raw
    $Job = Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8741/v1/character-jobs" `
      -ContentType "application/json" -Body $Body
    Start-Sleep -Milliseconds 400
    $Final = Invoke-RestMethod "http://127.0.0.1:8741/v1/character-jobs/$($Job.job_id)"
    $Health | ConvertTo-Json -Depth 6
    $Final | ConvertTo-Json -Depth 8
    if ($Final.state -ne "QUARANTINED_COMPLETE") { throw "P0 mock job failed" }
}
finally {
    Stop-Process -Id $Process.Id -Force -ErrorAction SilentlyContinue
}
