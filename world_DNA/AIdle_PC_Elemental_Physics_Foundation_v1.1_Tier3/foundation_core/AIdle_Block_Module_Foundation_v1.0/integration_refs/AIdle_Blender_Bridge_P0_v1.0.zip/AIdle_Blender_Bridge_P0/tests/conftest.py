from __future__ import annotations

import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("AIDLE_RUNNER_MODE", "mock")
    monkeypatch.setenv("AIDLE_BLENDER_EXECUTABLE", "blender-not-required-in-mock")

    from app.config import get_settings
    from app import dependencies

    get_settings.cache_clear()
    dependencies.get_template_registry.cache_clear()
    dependencies.get_operation_policy.cache_clear()
    dependencies.get_job_store.cache_clear()
    dependencies.get_blender_runner.cache_clear()
    dependencies.get_job_service.cache_clear()

    settings = get_settings()
    # Isolate storage while preserving repository config/scripts.
    settings.jobs_root = tmp_path / "jobs"
    settings.quarantine_root = tmp_path / "generated_quarantine"
    settings.evidence_root = tmp_path / "evidence"
    settings.rejected_root = tmp_path / "rejected"
    settings.ensure_directories()

    from app.main import app

    with TestClient(app) as test_client:
        yield test_client

    get_settings.cache_clear()
    dependencies.get_template_registry.cache_clear()
    dependencies.get_operation_policy.cache_clear()
    dependencies.get_job_store.cache_clear()
    dependencies.get_blender_runner.cache_clear()
    dependencies.get_job_service.cache_clear()
