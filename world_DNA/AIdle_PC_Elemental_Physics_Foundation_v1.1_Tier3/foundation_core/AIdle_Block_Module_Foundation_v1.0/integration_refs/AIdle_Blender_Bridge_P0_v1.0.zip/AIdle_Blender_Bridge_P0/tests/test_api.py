from __future__ import annotations

import copy


REQUEST = {
    "schema_version": "1.0",
    "request_id": "test-probe-001",
    "character_id": "P0-PROBE-001",
    "display_name": "Test Probe",
    "template_id": "p0_probe_empty_scene",
    "operation_profile": "p0_probe",
    "outputs": {
        "save_blend": True,
        "export_glb": True,
        "render_preview": True,
        "generate_validation_report": True,
    },
}


def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert data["runner_mode"] == "mock"
    assert data["template_count"] == 1


def test_templates(client):
    response = client.get("/v1/templates")
    assert response.status_code == 200
    assert response.json()["templates"][0]["template_id"] == "p0_probe_empty_scene"


def test_strict_schema_rejects_extra(client):
    payload = copy.deepcopy(REQUEST)
    payload["python_code"] = "print('blocked')"
    response = client.post("/v1/character-jobs", json=payload)
    assert response.status_code == 422


def test_unknown_template_rejected(client):
    payload = copy.deepcopy(REQUEST)
    payload["request_id"] = "test-probe-unknown"
    payload["template_id"] = "unknown_template"
    response = client.post("/v1/character-jobs", json=payload)
    assert response.status_code == 422


def test_mock_job_end_to_end(client):
    response = client.post("/v1/character-jobs", json=REQUEST)
    assert response.status_code == 202
    job_id = response.json()["job_id"]
    final = client.get(f"/v1/character-jobs/{job_id}")
    assert final.status_code == 200
    data = final.json()
    assert data["state"] == "QUARANTINED_COMPLETE"
    assert data["exit_code"] == 0
    assert any(path.endswith("validation.json") for path in data["artifacts"])


def test_duplicate_request_id(client):
    first = client.post("/v1/character-jobs", json=REQUEST)
    assert first.status_code == 202
    second = client.post("/v1/character-jobs", json=REQUEST)
    assert second.status_code == 409
