from pathlib import Path

from app.config import get_settings
from app.services.blender_runner import BlenderRunner


def test_real_command_contains_security_flags(tmp_path, monkeypatch):
    settings = get_settings()
    settings.runner_mode = "real"
    settings.blender_executable = Path("C:/Blender/blender.exe")
    settings.jobs_root = tmp_path / "jobs"
    settings.jobs_root.mkdir(parents=True)
    job_dir = settings.jobs_root / "BLD-TEST"
    job_dir.mkdir()
    spec = job_dir / "build_spec.internal.json"
    spec.write_text("{}", encoding="utf-8")

    runner = BlenderRunner(settings)
    command = runner.build_command(spec, job_dir)
    assert "--background" in command
    assert "--factory-startup" in command
    assert "--disable-autoexec" in command
    assert "--python-exit-code" in command
    assert "20" in command
    assert "--python" in command
