from pathlib import Path

import pytest

from app.security.path_policy import PathPolicyError, resolve_within, safe_child


def test_resolve_within_blocks_escape(tmp_path: Path):
    root = tmp_path / "root"
    root.mkdir()
    with pytest.raises(PathPolicyError):
        resolve_within(root, tmp_path / "outside.txt")


def test_safe_child_blocks_traversal(tmp_path: Path):
    with pytest.raises(PathPolicyError):
        safe_child(tmp_path, "../escape")
